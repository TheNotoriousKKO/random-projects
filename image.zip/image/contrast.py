from PIL import Image

def contrast(image, strength):
    grayscale_image = image.convert("L")

    contrast_image = Image.new("L", image.size)

    for x in range(image.width):
        for y in range(image.height):
            pixel_value = grayscale_image.getpixel((x, y))

            contrast_image.putpixel((x, y), pixel_value//strength*strength)  

    return contrast_image
            