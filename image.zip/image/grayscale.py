from PIL import Image

def single_threshold(image, threshold):
    grayscale_image = image.convert("L")

    bw_image = Image.new("L", image.size)

    for x in range(image.width):
        for y in range(image.height):
            pixel_value = grayscale_image.getpixel((x, y))

            if pixel_value >= threshold:
                bw_image.putpixel((x, y), 255)  
            else:
                bw_image.putpixel((x, y), 0) 

    return bw_image

def double_threshold(image, threshold1, threshold2):
    grayscale_image = image.convert("L")

    bw_image = Image.new("L", image.size)

    for x in range(image.width):
        for y in range(image.height):
            pixel_value = grayscale_image.getpixel((x, y))

            if pixel_value >= threshold1 and pixel_value <= threshold2:
                bw_image.putpixel((x, y), 255)  
            else:
                bw_image.putpixel((x, y), 0) 

    return bw_image

if __name__ == "__main__":
    with Image.open("yoda.jpeg") as image:
        newimage = single_threshold(image, 172)
        newimage.save("yoda_single_threshold.jpeg")