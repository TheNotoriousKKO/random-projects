from PIL import Image
import numpy as np

def blur(image):
    grey_image = image.convert("L")
    blur_image = grey_image
    height = image.height
    width = image.width

    
    summed_area = np.zeros((height, width), dtype=np.uint32)

    for y in range(height):
        for x in range(width):
            
            pixel_value = grey_image.getpixel((x, y))

            
            summed_value = pixel_value + summed_area[y-1, x] + summed_area[y, x-1] - summed_area[y-1, x-1]

        
            summed_area[y, x] = summed_value

    window_size = 71  

    for y in range(window_size, height-window_size):
        for x in range(window_size, width-window_size):
            
            mean_value = (summed_area[y+window_size, x+window_size] - summed_area[y-window_size, x+window_size] - summed_area[y+window_size, x-window_size] + summed_area[y-window_size, x-window_size]) // ((2*window_size + 1)**2)
            print(mean_value)
            blur_image.putpixel((x, y), int(mean_value))

    return blur_image

