from PIL import Image
import grayscale
import contrast
import blur
import time

if __name__ == "__main__":
    start_time = time.time()
    with Image.open("yoda.jpeg") as image:
        newimage = grayscale.single_threshold(image, 232)
        newimage.save("yoda_single_threshold.jpeg")
        print("Single Threshold time: --- %s seconds ---" % (time.time() - start_time))
        start_time = time.time()
        secondimage = grayscale.double_threshold(image,60, 160)
        secondimage.save("yoda_double_threshold.jpeg")
        print("Double Threshold time: --- %s seconds ---" % (time.time() - start_time))
        start_time = time.time()
        contrastimage = contrast.contrast(image, 87)
        contrastimage.save("yoda_contrast.jpeg")
        print("Contrast Threshold time: --- %s seconds ---" % (time.time() - start_time))
        start_time = time.time()
    with Image.open("road.jpg") as image:
        blurimage = blur.blur(image)
        blurimage.save("road_blur.jpeg")
        print("Blur image Threshold time: --- %s seconds ---" % (time.time() - start_time))
        
    
    print("--- %s seconds ---" % (time.time() - start_time))
    
