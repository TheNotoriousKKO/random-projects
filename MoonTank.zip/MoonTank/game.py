"""
===============================
          MOON TANK
===============================

A game by Jan Pawlak

Description: 'Moontank' is a game largely based on classic retro titles like
Space Invaders or Galaga. The aim is to survive as long as possible,
shooting oncoming enemies.

Uses OOP in the form of classes and various Pygame features, such as sprites.

All the sounds come from royalty free sources (freesound.org). All the
graphics are self-made.

Enjoy!
"""

import pygame
import random
import sys
from mpmath import cos, sin, pi, sqrt


class Player(pygame.sprite.Sprite):
    """Class for the player character"""

    def __init__(self, image_file, health):
        super().__init__()
        self.image = pygame.image.load(image_file)
        self.rect = self.image.get_rect()
        self.player_speed = 14
        self.pos_x = screen_width / 2
        self.pos_y = screen_height - 64
        self.rect.center = [self.pos_x, self.pos_y]
        self.health = health
        self.bomb_charge = 0

    def update(self):
        """Allows the movement of the player"""
        self.rect.center = self.pos_x, self.pos_y


class Cannon(pygame.sprite.Sprite):
    """Class for the gun mounted on top of the player, allows it to update
    visually depending on he position of the crosshair """

    def __init__(self, file1, file2, file3, file4, file5):
        super().__init__()
        self.sprites = []
        files = (file1, file2, file3, file4, file5)
        for file in files:
            self.sprites.append(pygame.image.load(file))

        self.current_sprite = 0
        self.image = self.sprites[self.current_sprite]
        self.rect = self.image.get_rect()
        self.pos_x = screen_width / 2
        self.pos_y = screen_height - 84
        self.rect.center = [self.pos_x, self.pos_y]
        self.angle = 0

        # self.angle = degrees(atan(self.pos_x - crosshair.rect.center[0]) /
        # (self.pos_y - crosshair.rect.center[1]))

    def update(self):
        self.rect.center = [player.pos_x, player.pos_y]
        if player.pos_x > crosshair.rect[0] + 160:
            self.current_sprite = 1
            if player.pos_x > crosshair.rect[0] + 380:
                self.current_sprite = 3
        elif player.pos_x < crosshair.rect[0] - 160:
            self.current_sprite = 2
            if player.pos_x < crosshair.rect[0] - 380:
                self.current_sprite = 4
        else:
            self.current_sprite = 0
        self.image = self.sprites[self.current_sprite]


class Crosshair(pygame.sprite.Sprite):
    """Class for displaing and interacting with the crosshair"""

    def __init__(self, image_file):
        super().__init__()
        self.image = pygame.image.load(image_file)
        self.rect = self.image.get_rect()
        self.shot_cooldown = 0

    def shoot(self):
        """Allows the player to shoot bullets"""
        if self.shot_cooldown == 0:
            self.shot_cooldown = 20
            if player.pos_x > crosshair.rect[0] + 160:
                self.angle = pi / - 7
                if player.pos_x > crosshair.rect[0] + 380:
                    self.angle = pi / -4
            elif player.pos_x < crosshair.rect[0] - 160:
                self.angle = pi / 7
                if player.pos_x < crosshair.rect[0] - 380:
                    self.angle = pi / 4
            else:
                self.angle = 0
            bullet = Bullet("bullet.png", player.pos_x, player.pos_y,
                            self.angle, bullet_speed)
            bullet_group.add(bullet)

    def launch_bomb(self):
        if player.bomb_charge == 10:
            player.bomb_charge = 0
            bomb = Bomb('bomb.png')
            bomb_group.add(bomb)

    def update(self):
        """moves the cursor"""
        self.rect.center = pygame.mouse.get_pos()


class Bullet(pygame.sprite.Sprite):
    """Class for bullets"""

    def __init__(self, image_file, pos_x, pos_y, angle, speed):
        super().__init__()

        self.image = pygame.image.load(image_file)
        self.rect = self.image.get_rect()
        self.rect.center = [pos_x, pos_y]
        self.angle = angle
        self.speed = speed
        self.move_x = self.speed * sin(self.angle)
        self.move_y = self.speed * -cos(self.angle)
        self.lifespan = 150
        self.explosion_sound = explosion_sound
        self.bullet_sound = bullet_sound
        self.bullet_sound.play(0)

    def update(self):
        """Allows the movement of the bullets + collision with enemies +
        despawns the bullets once they leave the screen """
        global score
        self.rect.x += int(self.move_x)
        self.rect.y += int(self.move_y)
        self.lifespan -= 1
        for enemy in enemy_group:
            if self.rect.colliderect(enemy.rect):
                explosion = Vfx('explosion.png', enemy.rect.x,
                                enemy.rect.y, 15)
                vfx_group.add(explosion)
                enemy.kill()
                score += 100
                if player.bomb_charge < 10:
                    player.bomb_charge += 1
                self.explosion_sound.play(0)

                self.kill()
        if self.lifespan == 0:
            self.kill()


class Bomb(pygame.sprite.Sprite):
    def __init__(self, image_file):
        super().__init__()
        self.image = pygame.image.load(image_file)
        self.rect = self.image.get_rect()
        self.rect.center = pygame.mouse.get_pos()
        self.runtime = 20
        self.range = 300

    def update(self):
        global score
        self.runtime -= 1
        if self.runtime == 0:
            bomb_explosion = Vfx('bomb_explosion.png', self.rect.centerx,
                                 self.rect.centery, 20)
            for enemy in enemy_group:
                dist = sqrt(
                    (self.rect.centerx - enemy.rect.centerx)
                    ** 2 + (self.rect.centery - enemy.rect.centery) ** 2)
                if dist < self.range:
                    score += 100
                    enemy.kill()
            bomb_explosion_sound.play(0)
            vfx_group.add(bomb_explosion)
            self.kill()


class Enemy(pygame.sprite.Sprite):
    """Class for the enemies, allows movement, changing direction,
    and dealing damage after reaching the bottom """

    def __init__(self, image_file, pos_x):
        super().__init__()
        self.image = pygame.image.load(image_file)
        self.rect = self.image.get_rect()
        self.crash_sound = crash_sound
        self.rect.center = [pos_x, 0]
        self.speed_x = random.randint(-10, 10)
        self.speed_y = random.randint(1, 3)
        self.turn = 0

    def update(self):
        self.rect.y += self.speed_y
        self.rect.x += self.speed_x
        self.turn = random.randint(0, 20)

        if self.rect.bottom > 720:
            self.crash()

        if self.turn == 0:
            self.speed_x = random.randint(-10, 10)
        elif self.rect.right > 1260:
            self.speed_x = -8
        elif self.rect.right < 0:
            self.speed_x = 8

    def crash(self):
        """Deals damage to the player"""
        global is_playing
        player.health -= 1
        if player.health == 0:
            is_playing = False
        self.crash_sound.play(0)
        explosion = Vfx('explosion.png', self.rect.x, self.rect.y, 15)
        vfx_group.add(explosion)
        self.kill()


class Vfx(pygame.sprite.Sprite):
    """Class for rendering visual effects"""

    def __init__(self, image_file, pos_x, pos_y, runtime):
        super().__init__()
        self.image = pygame.image.load(image_file)
        self.rect = self.image.get_rect()
        self.rect.center = [pos_x, pos_y]
        self.runtime = runtime

    def update(self):
        self.runtime -= 1
        if self.runtime == 0:
            self.kill()


def menu(screen):
    """function responsible for displaying and navigating the menu"""
    pygame.mixer.music.load('menutheme.mp3')
    pygame.mixer.music.play(-1)
    select_sound = pygame.mixer.Sound('select.wav')
    mode_dict = {2: "EASY",
                 1: "NORMAL",
                 0: "HARD"}
    difficulty = 1
    option = 0
    position_dict = {0: [380, 220],
                     1: [380, 380],
                     2: [380, 540]}
    menubg = pygame.image.load('menu.png')
    while True:
        screen.blit(menubg, [0, 0])
        play_surf = font.render(f'PLAY', True, (255, 255, 255))
        playRect = play_surf.get_rect()
        playRect.center = (screen_width / 2, 275)
        screen.blit(play_surf, playRect)
        mode_surf = font.render(f'{mode_dict[difficulty]}', True,
                                (255, 255, 255))
        modeRect = mode_surf.get_rect()
        modeRect.center = (screen_width / 2, 435)
        screen.blit(mode_surf, modeRect)
        exit_surf = font.render(f'EXIT', True, (255, 255, 255))
        exitRect = exit_surf.get_rect()
        exitRect.center = (screen_width / 2, 595)
        screen.blit(exit_surf, exitRect)
        cursor = pygame.image.load('cursor.png')
        screen.blit(cursor, position_dict[option])
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            keys = pygame.key.get_pressed()
            if keys[pygame.K_UP] or keys[pygame.K_s]:
                option -= 1
                if option < 0:
                    option = 2
                pygame.display.update()
            if keys[pygame.K_DOWN] or keys[pygame.K_w]:
                option += 1
                if option > 2:
                    option = 0
                pygame.display.update()
            if keys[pygame.K_SPACE]:
                select_sound.play(0)
                match option:
                    case 0:
                        instructions(screen, 'help.png')
                        return difficulty
                    case 1:
                        difficulty += 1
                        if difficulty > 2:
                            difficulty = 0
                    case 2:
                        pygame.quit()
                        sys.exit()
            pygame.display.update()


def instructions(screen, image_path):
    while True:
        help = pygame.image.load(image_path)
        screen.blit(help, [0, 0])
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            keys = pygame.key.get_pressed()
            if keys[pygame.K_SPACE]:
                return


def endgame(screen, score, spritegroups):
    """Function triggers when the player loses all lives, ends the game"""
    pygame.mixer.music.load('gameover.mp3')
    pygame.mixer.music.play(-1)
    for group in spritegroups:
        group.empty()
    screen.fill("black")
    end_surf = font.render(f'Game over! Your score was: {score}', True,
                           (255, 255, 255))
    endRect = end_surf.get_rect()
    click_surf = font.render(f' Press Space to continue', True,
                             (255, 255, 255))
    clickRect = click_surf.get_rect()
    endRect.center = (screen_width / 2, screen_height / 3)
    clickRect.center = (screen_width / 2, screen_height / 2)
    screen.blit(end_surf, endRect)
    screen.blit(click_surf, clickRect)
    pygame.display.update()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            keys = pygame.key.get_pressed()
            if keys[pygame.K_SPACE]:
                return


# GENERAL SETUP
# Pygame
pygame.init()
clock = pygame.time.Clock()
# Screen
screen_width = 1280
screen_height = 720
screen = pygame.display.set_mode((screen_width, screen_height))
font = pygame.font.Font('font.ttf', 32)
pygame.mouse.set_visible(False)
while True:
    difficulty = menu(screen)

    # GAME SETUP
    # General
    is_playing = True
    pygame.mixer.music.load('fightmusic2.mp3')
    pygame.mixer.music.play(-1)
    background = pygame.image.load("earth bg.png")

    # HUD
    score = 0
    score_surf = font.render(f'Score: {score}', True, (255, 255, 255),
                             (0, 0, 0))
    scoreRect = score_surf.get_rect()
    scoreRect.left = 10
    scoreRect.top = 10

    wave = 1
    wave_surf = font.render(f'Wave {3}', True, (255, 255, 255))
    waveRect = wave_surf.get_rect()
    waveRect.right = (screen_width - 150) / 2
    waveRect.top = 10

    hp_surf = font.render(f'Hp: {3}', True, (255, 255, 255))
    hpRect = hp_surf.get_rect()
    hpRect.left = (screen_width - 80) / 2
    hpRect.top = 10

    bomb_surf = font.render(f'Bomb charge: {0}%', True, (255, 255, 255))
    bombRect = bomb_surf.get_rect()
    bombRect.right = screen_width - 30
    bombRect.top = 10

    # SFX
    bullet_sound = pygame.mixer.Sound('gun.wav')
    explosion_sound = pygame.mixer.Sound('boom.wav')
    crash_sound = pygame.mixer.Sound('crash.aiff')
    bomb_explosion_sound = pygame.mixer.Sound('bomb_explosion.wav')

    # Crosshair
    crosshair = Crosshair("crosshair.png")
    crosshair_group = pygame.sprite.Group()
    crosshair_group.add(crosshair)

    # Player
    player = Player("player.png", 3 + difficulty)
    player_group = pygame.sprite.Group()
    player_group.add(player)
    moveticker = 0
    bullet_speed = 10

    # Bullets
    bullet_group = pygame.sprite.Group()

    # Bomb
    bomb_group = pygame.sprite.Group()

    # Cannon
    cannon = Cannon('cannonmid.png', 'cannonleft.png', 'cannonright.png',
                    'cannonfarleft.png', 'cannonfarright.png')
    cannon_group = pygame.sprite.Group()
    cannon_group.add(cannon)

    # Enemies
    enemy_group = pygame.sprite.Group()
    enemy_number = 4 - difficulty
    for enemy in range(enemy_number):
        new_enemy = Enemy("enemy.png", random.randrange(20, screen_width - 20))
        enemy_group.add(new_enemy)
    spawn_enemy = 300
    enemy_countdown = 0

    # VFX
    vfx_group = pygame.sprite.Group()

    # Game Loop
    while is_playing:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                crosshair.shoot()
        keys = pygame.key.get_pressed()
        if keys[pygame.K_a]:
            if moveticker == 0:
                moveticker = 2
                if player.rect.left > 0:
                    player.pos_x -= player.player_speed
        if keys[pygame.K_d]:
            if moveticker == 0:
                moveticker = 2
                if player.rect.right < 1280:
                    player.pos_x += player.player_speed
        if keys[pygame.K_SPACE]:
            crosshair.launch_bomb()

        pygame.display.flip()
        if moveticker > 0:
            moveticker -= 1
        if crosshair.shot_cooldown > 0:
            crosshair.shot_cooldown -= 1
        enemy_countdown += 1
        if enemy_countdown == spawn_enemy:
            for enemy in range(enemy_number):
                new_enemy = Enemy("enemy.png",
                                  random.randrange(20, screen_width - 20))
                enemy_group.add(new_enemy)
            enemy_countdown = 0
            wave += 1
            enemy_number += random.randint(0, 5-difficulty)
            if enemy_number > 10 and spawn_enemy > 50:
                enemy_number = 4
                spawn_enemy -= 50
        screen.blit(background, [0, 0])
        enemy_group.draw(screen)
        crosshair_group.draw(screen)
        player_group.draw(screen)
        cannon_group.draw(screen)
        bullet_group.draw(screen)
        bomb_group.draw(screen)
        vfx_group.draw(screen)
        score_surf = font.render(f'Score:{score}', True, (255, 255, 255))
        screen.blit(score_surf, scoreRect)
        wave_surf = font.render(f'Wave:{wave}', True, (255, 255, 255))
        screen.blit(wave_surf, waveRect)
        hp_surf = font.render(f'Hp:{player.health}', True, (255, 255, 255))
        screen.blit(hp_surf, hpRect)
        charge_surf = font.render(f'Bomb charge:{player.bomb_charge * 10}%',
                                  True, (255, 255, 255))
        screen.blit(charge_surf, bombRect)

        crosshair_group.update()
        player_group.update()
        cannon_group.update()
        bullet_group.update()
        bomb_group.update()
        vfx_group.update()
        enemy_group.update()

        clock.tick(60)
    endgame(screen, score,
            (player_group, enemy_group, bomb_group, bomb_group, cannon_group,
             crosshair_group, bullet_group))
